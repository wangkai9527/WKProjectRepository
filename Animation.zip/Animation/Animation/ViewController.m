//
//  ViewController.m
//  Animation
//
//  Created by mac on 2020/12/25.
//

#import "ViewController.h"
//头像
#import "headImageView.h"
//输入框
#import "WK_CHTextFiled.h"




@interface ViewController ()

@property(nonatomic,strong)WK_CHTextFiled * textFiled;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIImageView * imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"背景图"]];
    imageView.frame = self.view.frame;
    //        imageView.center = self.view.center;
//    imageView.layer.cornerRadius = 75;
//    imageView.layer.masksToBounds = YES;
//    imageView.userInteractionEnabled = YES;
//    imageView.contentMode = UIViewContentModeScaleAspectFill;
//    [imageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(editPersonMsg)]];
    [self.view addSubview:imageView];
//    headImageView *viewA = [[headImageView alloc] initWithFrame:CGRectMake(0, 0, 150, 150) animationType:AnimationTypeWithBackground];
//    viewA.center = imageView.center;
//
//    CABasicAnimation *scaleAnimation = [[CABasicAnimation alloc]init];
//
//    scaleAnimation.fromValue = @0.5;
//    scaleAnimation.toValue = @1;
//    [imageView.layer addAnimation:scaleAnimation forKey:@"transform.scale"];
    
//    [self.view addSubview:viewA];
//    [self.view addSubview:imageView];
    
    [self.view addSubview:self.textFiled];
    
}
-(void)editPersonMsg{
    NSLog(@"跳转个人中心");
}
-(WK_CHTextFiled *)textFiled{
    if (!_textFiled) {
        _textFiled = [[WK_CHTextFiled alloc]initWithFrame:CGRectMake(60, 100,self.view.frame.size.width - 120 , 40)];
        _textFiled.placeholder = @"请输入内容......";
        _textFiled.borderStyle = UITextBorderStyleRoundedRect;
        
    }
    return _textFiled;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.textFiled resignFirstResponder];
}
//汉字转 拼音
- (NSString *)transform:(NSString *)chinese{
    NSMutableString *pinyin = [chinese mutableCopy];
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformMandarinLatin, NO);
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformStripCombiningMarks, NO);
    
    return [pinyin uppercaseString];
}
@end
