//
//  AppDelegate.h
//  Animation
//
//  Created by mac on 2020/12/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic,strong)UIWindow * window;

@end

