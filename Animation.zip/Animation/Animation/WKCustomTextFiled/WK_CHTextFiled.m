//
//  WK_CHTextFiled.m
//  Animation
//
//  Created by mac on 2021/1/9.
//

#import "WK_CHTextFiled.h"
//自定义键盘View
#import "WKCustomKeyBoard.h"
//inputView
#import "WKCustominputView.h"

//屏幕的宽
#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
//屏幕的高
#define SCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height

@interface WK_CHTextFiled ()<WKCustomKeyBoardDelegate>
@property(nonatomic,strong)WKCustomKeyBoard * boardView;
@property(nonatomic,strong)WKCustominputView * inputCustomView;

@end

@implementation WK_CHTextFiled

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}
//UI
-(void)createUI{
    
    //中间的 inputView
    self.inputView = self.boardView;
    //顶部的 inputAccessoryView
    self.inputAccessoryView = self.inputCustomView;
    
}
//键盘输入的文字
-(void)keyBoardEnterString:(NSString *)text{
    self.text = text;
}
-(WKCustomKeyBoard *)boardView{
    if (!_boardView) {
        _boardView = [[WKCustomKeyBoard alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT / 3)];
        _boardView.delegate = self;
    }
    return _boardView;
}
-(WKCustominputView *)inputCustomView{
    if (!_inputCustomView) {
        _inputCustomView = [[WKCustominputView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 46)];
      
    }
    return _inputCustomView;
}
@end
