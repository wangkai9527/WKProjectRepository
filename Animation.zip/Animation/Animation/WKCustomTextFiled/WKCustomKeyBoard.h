//
//  WKCustomKeyBoard.h
//  Animation
//
//  Created by mac on 2021/1/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WKCustomContentCell :UICollectionViewCell
//按钮
@property(nonatomic,strong)UILabel * textLabel;

@end

@protocol WKCustomKeyBoardDelegate <NSObject>

//键盘输入的文字
-(void)keyBoardEnterString:(NSString *)text;

@optional

@end

@interface WKCustomKeyBoard : UIView
//协议
@property(nonatomic,weak)id<WKCustomKeyBoardDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
