//
//  WKKeyTypeView.m
//  Animation
//
//  Created by mac on 2021/1/11.
//

#import "WKKeyTypeView.h"

@implementation WKKeyTypeView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}
-(void)createUI{
    
    self.backgroundColor = [UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1.0];
    
    NSArray * typesArray = @[@"中文键盘",@"英文键盘",@"数字键盘"];
    
    CGFloat button_Width = (self.frame.size.width - (typesArray.count + 1) * 15) / typesArray.count;
    
    for (int i = 0; i<typesArray.count; i++) {
        
        UIButton * bordCell = [UIButton buttonWithType:UIButtonTypeCustom];
        bordCell.backgroundColor = [UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0];
        bordCell.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        //设置按钮的文案
        [bordCell setTitle:[typesArray objectAtIndex:i] forState:UIControlStateNormal];
        [bordCell setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        bordCell.tag = i;
        //切圆角
        bordCell.layer.cornerRadius = 8;
        bordCell.layer.masksToBounds = YES;
        bordCell.adjustsImageWhenHighlighted=NO;
        bordCell.frame = CGRectMake(i * (button_Width +15) + 15, 10, button_Width,30);
        
        //按钮点击方法
        [bordCell addTarget:self action:@selector(toolsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:bordCell];
    }
}
//按钮点击
-(void)toolsButtonClick:(UIButton *)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(keyTypeButtonAction:)]) {
        [self.delegate keyTypeButtonAction:sender.tag];
    }
}
@end
