//
//  WKCustomKeyBoard.m
//  Animation
//
//  Created by mac on 2021/1/8.
//

#import "WKCustomKeyBoard.h"
//选择键盘类型view
#import "WKKeyTypeView.h"

@implementation WKCustomContentCell

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}

-(void)createUI{
   
    self.textLabel = [[UILabel alloc]initWithFrame:CGRectMake(2, 2, 40, 40)];
    self.textLabel.textAlignment = NSTextAlignmentCenter;
    self.textLabel.layer.cornerRadius = 20;
    self.textLabel.layer.masksToBounds = YES;
    self.textLabel.font = [UIFont boldSystemFontOfSize:15];
    self.textLabel.backgroundColor = [UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0];
    //添加
    [self addSubview:self.textLabel];
  
    //设置阴影
    self.layer.shadowColor = [UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:0.5].CGColor;
    self.layer.shadowOffset = CGSizeMake(2, 2);
    self.layer.shadowOpacity = 0.7;
    self.layer.shadowRadius = 2;
    //切成圆形
    self.layer.cornerRadius = 20;
    self.layer.masksToBounds = NO;
    
    
   
    //添加长按手势 按钮抖动动画
    UILongPressGestureRecognizer *pan = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(handleDragGesture:)];
    [self addGestureRecognizer:pan];
    //添加漂浮动画
   //        [self configAniamtionLikeGameCenterBubbleByCustomView:bordCell];
}
#pragma mark  -----------------------------------------------  👉 长按手势动画 👈  ----------------------------------------------------------
-(void)handleDragGesture:(UILongPressGestureRecognizer *)pan{
    
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animation];
    anim.duration = 0.2;
    anim.keyPath = @"transform";
    NSValue *value =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((-25) / 180.0 * M_PI, 0, 0, 1)];
    NSValue *value1 =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((25) / 180.0 * M_PI, 0, 0, 1)];
    NSValue *value2 =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((-25) / 180.0 * M_PI, 0, 0, 1)];
    anim.values = @[value,value1,value2];
    anim.repeatCount = 1;
    [pan.view.layer addAnimation:anim forKey:nil];
    
}
@end


@interface WKCustomKeyBoard ()<UICollectionViewDelegate,UICollectionViewDataSource,ChooseKeyTypeViewDelegate>
//返回的字符串
@property(nonatomic,copy)NSString * returString;
//collectionView
@property(nonatomic,strong)UICollectionView * collectionView;
//数据源
@property(nonatomic,copy)NSArray * titleArray;
//键盘类型View
@property(nonatomic,strong)WKKeyTypeView * keyTypeView;
//用来展示选择键盘类型
@property(nonatomic,assign)BOOL isShow;
//键盘类型的按钮
@property(nonatomic,strong)UIButton * keyTypeButton;
@end

@implementation WKCustomKeyBoard

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}
-(void)createUI{
    
    self.returString = @"";
    
    self.isShow = NO;
    
    self.backgroundColor = [UIColor whiteColor];
    
#pragma mark  -----------------------------------------------  👉 汉字内容列表 👈  ----------------------------------------------------------
    
    self.titleArray = @[@"我",@"你",@"他",@"她",@"它",@"点",@"起",@"电",@"店",@"一",@"次",@"辞",@"词",@"此",@"慈",@"想",@"像",@"详",@"新",@"心",@"信",@"爱",@"哎",@"唉",@"挨",@"比",@"笔",@"币",@"逼",@"必",@"闭",@"关",@"管",@"官",@"馆",@"第",@"地",@"低",@"滴",@"递",@"吗",@"嘛",@"马",@"上",@"尚",@"记",@"几",@"个",@"哥",@"歌",@"各",@"格",@"隔",@"里",@"礼",@"字",@"自",@"子",@"紫",@"资",@"姿",@"滋",@"为",@"位",@"喂",@"未",@"没",@"美",@"妹",@"每",@"梅",@"煤",@"眉",@"莓",@"草",@"数",@"书",@"输",@"熟",@"叔",@"术",@"树",@"鼠",@"舒",@"竖",@"哼",@"哈",@"好",@"是"];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(45, 45);
    layout.minimumLineSpacing = 0;
    layout.minimumInteritemSpacing = 0;
    layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(5, 0, self.frame.size.width - 70, self.frame.size.height - 50) collectionViewLayout:layout];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.collectionView.showsVerticalScrollIndicator = NO;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
  
    [self.collectionView registerClass:[WKCustomContentCell class] forCellWithReuseIdentifier:@"WKCustomContentCell"];
    
    [self addSubview:self.collectionView];
    
    //按钮的宽和高
    CGFloat  width = 40;

    UIFont * font = [UIFont boldSystemFontOfSize:15];
    
#pragma mark  -----------------------------------------------  👉 右边标点符号列表 👈  ----------------------------------------------------------
    
    NSArray * symbolArray = @[@"，",@"。",@"?",@"!",@".",@"@",@"*",@"#",@"%",@"-",@"+",@"="];
    
    UIScrollView * symbolView = [[UIScrollView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.collectionView.frame)+5, 0, 55, self.frame.size.height - 50)];
    symbolView.showsVerticalScrollIndicator = NO;
    symbolView.backgroundColor = [UIColor whiteColor];
    symbolView.layer.masksToBounds = YES;
    symbolView.layer.cornerRadius = 5;
    [self addSubview:symbolView];
    
    for (int i = 0; i<symbolArray.count; i++) {
        
        UIButton * bordCell = [UIButton buttonWithType:UIButtonTypeCustom];
        bordCell.backgroundColor = [UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0];
        bordCell.titleLabel.font = font;
        //设置按钮的文案
        [bordCell setTitle:[symbolArray objectAtIndex:i] forState:UIControlStateNormal];
        [bordCell setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //设置阴影
        bordCell.layer.shadowColor = [UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:0.5].CGColor;
        bordCell.layer.shadowOffset = CGSizeMake(2, 2);
        bordCell.layer.shadowOpacity = 0.7;
        //阴影半径，默认3
        bordCell.layer.shadowRadius = 3;
        //切成圆形
        bordCell.layer.cornerRadius = width / 2;
        
        bordCell.frame = CGRectMake(8, i * (width + 10) + 2, width,width);
        
        //按钮点击方法
        [bordCell addTarget:self action:@selector(toolsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [symbolView addSubview:bordCell];
        
        //修改scrollView的最大滚动范围
        symbolView.contentSize=CGSizeMake(50, bordCell.frame.origin.y + width + 15);
        
        UILongPressGestureRecognizer *pan = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(handleDragGesture:)];
        [bordCell addGestureRecognizer:pan];
    }
#pragma mark  -----------------------------------------------  👉 键盘类型View  👈  ----------------------------------------------------------
    
    self.keyTypeView = [[WKKeyTypeView alloc]initWithFrame:CGRectMake(0, self.frame.size.height - 50, self.frame.size.width, 1)];
    self.keyTypeView.userInteractionEnabled = YES;
    self.keyTypeView.delegate = self;
    [self addSubview:self.keyTypeView];
#pragma mark  -----------------------------------------------  👉 最下面删除 和 空格按钮 👈  ----------------------------------------------------------
    
    NSArray * toolsArray = @[@"键盘类型",@"空格",@"删除"];
    
    CGFloat button_Width = (self.frame.size.width - (toolsArray.count + 1) * 15) / toolsArray.count;
    
    for (int i = 0; i<toolsArray.count; i++) {
        
        UIButton * bordCell = [UIButton buttonWithType:UIButtonTypeCustom];
        bordCell.backgroundColor = [UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0];
        bordCell.titleLabel.font = font;
        //设置按钮的文案
        [bordCell setTitle:[toolsArray objectAtIndex:i] forState:UIControlStateNormal];
        [bordCell setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //设置阴影
        bordCell.layer.shadowColor = [UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:0.5].CGColor;
        bordCell.layer.shadowOffset = CGSizeMake(2, 2);
        bordCell.layer.shadowOpacity = 0.7;
        //阴影半径，默认3
        bordCell.layer.shadowRadius = 3;
        //切圆角
        bordCell.layer.cornerRadius = 8;
        
        bordCell.frame = CGRectMake(i * (button_Width +15) + 15, CGRectGetMaxY(symbolView.frame) + 10, button_Width,30);
        
        //按钮点击方法
        [bordCell addTarget:self action:@selector(toolsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:bordCell];
        
    }
}
#pragma mark  -----------------------------------------------  👉 长按手势动画 👈  ----------------------------------------------------------
-(void)handleDragGesture:(UILongPressGestureRecognizer *)pan{
    
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animation];
    anim.duration = 0.2;
    anim.keyPath = @"transform";
    NSValue *value =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((-25) / 180.0 * M_PI, 0, 0, 1)];
    NSValue *value1 =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((25) / 180.0 * M_PI, 0, 0, 1)];
    NSValue *value2 =  [NSValue valueWithCATransform3D:CATransform3DMakeRotation((-25) / 180.0 * M_PI, 0, 0, 1)];
    anim.values = @[value,value1,value2];
    anim.repeatCount = 1;
    [pan.view.layer addAnimation:anim forKey:nil];
    
}
#pragma mark  -----------------------------------------------  👉 漂浮动画 👈  ----------------------------------------------------------
-(void)configAniamtionLikeGameCenterBubbleByCustomView:(UIView *)custum {
    
    CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    pathAnimation.calculationMode = kCAAnimationPaced;
    pathAnimation.fillMode = kCAFillModeForwards;
    pathAnimation.removedOnCompletion = NO;
    pathAnimation.repeatCount = INFINITY;
    pathAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    pathAnimation.duration = 5.0;
    
    CGMutablePathRef curvedPath = CGPathCreateMutable();
    CGRect circleContainer = CGRectInset(custum.frame, custum.bounds.size.width / 2 - 3, custum.bounds.size.width / 2 - 3);
    CGPathAddEllipseInRect(curvedPath, NULL, circleContainer);
    
    pathAnimation.path = curvedPath;
    CGPathRelease(curvedPath);
    [custum.layer addAnimation:pathAnimation forKey:@"myCircleAnimation"];
    
    CAKeyframeAnimation *scaleX = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale.x"];
    scaleX.duration = 1;
    scaleX.values = @[@1.0, @1.1, @1.0];
    scaleX.keyTimes = @[@0.0, @0.5, @1.0];
    scaleX.repeatCount = INFINITY;
    scaleX.autoreverses = YES;
    
    scaleX.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [custum.layer addAnimation:scaleX forKey:@"scaleXAnimation"];
    
    
    CAKeyframeAnimation *scaleY = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale.y"];
    scaleY.duration = 1.5;
    scaleY.values = @[@1.0, @1.1, @1.0];
    scaleY.keyTimes = @[@0.0, @0.5, @1.0];
    scaleY.repeatCount = INFINITY;
    scaleY.autoreverses = YES;
    scaleY.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [custum.layer addAnimation:scaleY forKey:@"scaleYAnimation"];
    
}
#pragma mark  -----------------------------------------------  👉 内容按钮点击监听 👈  ----------------------------------------------------------
-(void)bordCellClick:(UIButton *)sender{
    
    //拿到按钮的文案
    NSString * text = sender.titleLabel.text;
    self.returString = [NSString stringWithFormat:@"%@%@",self.returString,text];
    //调用代理方法
    if (self.delegate && [self.delegate respondsToSelector:@selector(keyBoardEnterString:)]) {
        [self.delegate keyBoardEnterString:self.returString];
    }
    
}
#pragma mark  -----------------------------------------------  👉 符号按钮点击监听 👈  ----------------------------------------------------------
-(void)toolsButtonClick:(UIButton *)sender{
    
    NSString * text = sender.titleLabel.text;
    
    if ([text isEqualToString:@"删除"]) {
        //如果是删除就把text去掉最后一位
        if (self.returString.length == 0) return;
        self.returString = [self.returString substringToIndex:self.returString.length - 1];
        
    }else if ([text isEqualToString:@"空格"]){
        //如果是空格就把text改成空格
        text = @"  ";
        self.returString = [NSString stringWithFormat:@"%@%@",self.returString,text];
        
    }else if ([text isEqualToString:@"键盘类型"]){
        self.keyTypeButton = sender;
        sender.selected = !sender.selected;
        self.isShow = sender.selected;
        if (self.isShow) {
            //修改frame
            [sender setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            sender.backgroundColor = [UIColor colorWithRed:105.0/255.0 green:105.0/255.0 blue:105.0/255.0 alpha:1.0];
            [UIView animateWithDuration:0.2 animations:^{
            self.keyTypeView.frame = CGRectMake(0, self.frame.size.height - 100, self.frame.size.width, 50);
            }];
        }else{
            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            sender.backgroundColor = [UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0];
            [UIView animateWithDuration:0.2 animations:^{
                self.keyTypeView.frame = CGRectMake(0, self.frame.size.height - 50, self.frame.size.width, 1);
            } completion:nil];
        }
        
    }else{
        //字符串赋值
        self.returString = [NSString stringWithFormat:@"%@%@",self.returString,text];
    }
    
    //调用代理方法
    if (self.delegate && [self.delegate respondsToSelector:@selector(keyBoardEnterString:)]) {
        [self.delegate keyBoardEnterString:self.returString];
    }
    
}
#pragma mark  -----------------------------------------------  👉 选择键盘类型事件监听 👈  ----------------------------------------------------------
//选择键盘的代理方法
-(void)keyTypeButtonAction:(NSInteger)index{
    
    [self.keyTypeButton setTitle:@"键盘类型" forState:UIControlStateNormal];
    [self toolsButtonClick:self.keyTypeButton];
    
    //修改frame
    [UIView animateWithDuration:0.2 animations:^{
        self.keyTypeView.frame = CGRectMake(0, self.frame.size.height - 50, self.frame.size.width, 1);
    } completion:nil];
    if (index == 0) {
        self.titleArray = @[@"我",@"你",@"他",@"她",@"它",@"点",@"起",@"电",@"店",@"一",@"次",@"辞",@"词",@"此",@"慈",@"想",@"像",@"详",@"新",@"心",@"信",@"爱",@"哎",@"唉",@"挨",@"比",@"笔",@"币",@"逼",@"必",@"闭",@"关",@"管",@"官",@"馆",@"第",@"地",@"低",@"滴",@"递",@"吗",@"嘛",@"马",@"上",@"尚",@"记",@"几",@"个",@"哥",@"歌",@"各",@"格",@"隔",@"里",@"礼",@"字",@"自",@"子",@"紫",@"资",@"姿",@"滋",@"为",@"位",@"喂",@"未",@"没",@"美",@"妹",@"每",@"梅",@"煤",@"眉",@"莓",@"草",@"数",@"书",@"输",@"熟",@"叔",@"术",@"树",@"鼠",@"舒",@"竖",@"哼",@"哈",@"好",@"是"];
        
    }else if(index == 1){
        self.titleArray = @[@"q",@"w",@"e",@"r",@"t",@"y",@"u",@"i",@"o",@"p",@"a",@"s",@"d",@"f",@"g",@"h",@"j",@"k",@"l",@"z",@"x",@"c",@"v",@"b",@"n",@"m"];
    }else{
        self.titleArray = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"0"];
    }
    [self.collectionView reloadData];
    
}

#pragma mark  -----------------------------------------------  👉 collectionView 代理方法 👈  ----------------------------------------------------------

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.titleArray.count;
}
-(__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    WKCustomContentCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"WKCustomContentCell" forIndexPath:indexPath];
    cell.textLabel.text = [self.titleArray objectAtIndex:indexPath.item];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //拿到按钮的文案
    NSString * text = [self.titleArray objectAtIndex:indexPath.item];
    self.returString = [NSString stringWithFormat:@"%@%@",self.returString,text];
    //调用代理方法
    if (self.delegate && [self.delegate respondsToSelector:@selector(keyBoardEnterString:)]) {
        [self.delegate keyBoardEnterString:self.returString];
    }
}

@end
