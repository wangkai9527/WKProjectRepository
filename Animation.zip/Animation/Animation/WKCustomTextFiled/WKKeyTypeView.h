//
//  WKKeyTypeView.h
//  Animation
//
//  Created by mac on 2021/1/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ChooseKeyTypeViewDelegate <NSObject>

-(void)keyTypeButtonAction:(NSInteger)index;

@optional

@end

@interface WKKeyTypeView : UIView
//协议
@property(nonatomic,weak)id<ChooseKeyTypeViewDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
