//
//  WKCustominputView.h
//  Animation
//
//  Created by mac on 2021/1/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WKCustominputView : UIView

@end

NS_ASSUME_NONNULL_END
