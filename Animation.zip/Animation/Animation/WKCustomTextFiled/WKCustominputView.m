//
//  WKCustominputView.m
//  Animation
//
//  Created by mac on 2021/1/9.
//

#import "WKCustominputView.h"

@implementation WKCustominputView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}
// UI
-(void)createUI{
    
    self.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.9];
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:UIRectCornerTopLeft |UIRectCornerTopRight cornerRadii:CGSizeMake(10, 10)];
    CAShapeLayer*maskLayer = [[CAShapeLayer alloc]init];
    //设置大小
    maskLayer.frame= self.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    self.layer.mask = maskLayer;
    

    NSArray * typesArray = @[@"icon1",@"icon2",@"icon3",@"icon4"];
    
    for (int i = 0; i<typesArray.count; i++) {
        
        UIButton * bordCell = [UIButton buttonWithType:UIButtonTypeCustom];
        
        bordCell.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        //设置按钮的文案
        [bordCell setImage:[UIImage imageNamed:[typesArray objectAtIndex:i]] forState:UIControlStateNormal];
        bordCell.tag = i;
        //切圆角
        bordCell.layer.cornerRadius = 8;
        bordCell.layer.masksToBounds = YES;
        bordCell.adjustsImageWhenHighlighted=NO;
        bordCell.frame = CGRectMake(i * 45 + 15, 10, 30,30);
        
        //按钮点击方法
        [bordCell addTarget:self action:@selector(toolsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:bordCell];
    }
    
    
}
//按钮点击监听
-(void)toolsButtonClick:(UIButton *)sender{
    
    
}
@end
