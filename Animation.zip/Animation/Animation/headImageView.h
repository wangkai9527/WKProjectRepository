//
//  headImageView.h
//  Animation
//
//  Created by mac on 2020/12/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, AnimationType) {
    AnimationTypeWithBackground,
    AnimationTypeWithoutBackground
};

@interface headImageView : UIView
/**

设置扩散倍数。默认1.423倍
*/
@property (nonatomic, assign) CGFloat multiple;

- (instancetype)initWithFrame:(CGRect)frame animationType:(AnimationType)animationType;

@end

NS_ASSUME_NONNULL_END
